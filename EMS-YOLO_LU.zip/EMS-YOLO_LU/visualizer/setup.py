import setuptools

setuptools.setup(
    name="visualizer",
    version="0.0.1",
    author="luo3300612",
    author_email="591486669@qq.com",
    packages=setuptools.find_packages(),
)